﻿var dict = {
	"Options": {
		fr: "Préférences",
		pt: "Opções"
	},
	"Number of Digits": {
		fr: "Nombre de chiffres",
		pt: "Número de dígitos"
	},
	"Scrolling Number": {
		fr: "Chiffre en répétition",
		pt: "Número de Rolagem"
	},
	"Game Language": {
		fr: "Game Language",
		pt: "Idioma do jogo"
	},
	"Font Color": {
		fr: "Font Color"
	},
	"Type of Operation": {
		fr: "Type of Operation"
	},
	"Replay": {
		fr: "Replay"
	},
	"Your answer": {
		fr: "Your answer"
	},
	"Check": {
		fr: "Check"
	},
	"Play": {
		fr: "Play"
	},
	"Max Sum": {
		fr: "Somme maximum"
	},
	"Flash (ms)": {
		fr: "Flash (ms)"
	},
	"Background Color": {
		fr: "Background Color"
	},
	"Assistant Fingers": {
		fr: "Assistant Fingers"
	},
	"Target Sum": {
		fr: "Résultat final"
	},
	"Timeout (ms)": {
		fr: "Temps mort (ms)"
	},
	"Continuous mode (hands free)": {
		fr: "Mode continu  <br>  (sans \"les mains\")"
	},
	"Number of Rows": {
		fr: "Nombre de ligne"
	},
	"Font Size": {
		fr: "Font Size"
	},
	"bigger": {
		fr: "bigger"
	},
	"smaller": {
		fr: "smaller"
	},
	"OK": {
		fr: "OK"
	},
}